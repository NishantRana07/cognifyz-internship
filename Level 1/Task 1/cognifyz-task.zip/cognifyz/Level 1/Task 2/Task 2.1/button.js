const a=document.getElementById('colorButton')
a.addEventListener('click',function(){
a.classList.toggle('clicked');
})